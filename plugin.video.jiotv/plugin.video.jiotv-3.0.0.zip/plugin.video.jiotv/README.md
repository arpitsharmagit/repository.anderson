<h2 align="center">
  <br>
  <img src="resources/icon.png" height="60" width="60">
  <br>
  JioTV
  <br>
</h2>

<h4 align="center">JioTV Kodi Add-on</h4>

<br>

## Disclaimer

This plugin is not officially commissioned/supported by Jio. The trademark "Jio" is registered by "Reliance Corporate IT Park Limited (RCITPL)"

## Download

[**Download**](https://github.com/anderson/plugin.video.jiotv/releases/latest) the `.zip` file.
